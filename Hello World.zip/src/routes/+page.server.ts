export async function load() {
	return {
		name: 'TypeScript'
	};
}
