<script>
	import './global.css';
</script>

<slot />
