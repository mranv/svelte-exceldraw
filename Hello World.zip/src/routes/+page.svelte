<script lang="ts">
	import Excali from "$lib/AsyncExcalidraw.svelte";
</script>

<h1>Hello Excalidraw from svelte</h1>

<Excali />

